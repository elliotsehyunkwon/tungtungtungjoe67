# Midnight Bat Club — Tung Tung Sahur

A self-contained, pixel-art 2D aim-training survival game. No dependencies, build step, accounts, or external assets.

## Play locally
Open `index.html` in a modern desktop browser (Chrome, Firefox, Edge, Safari). Keyboard and mouse recommended; touch can aim and swing but full movement needs a keyboard.

## Controls
- WASD / arrow keys: move
- Mouse: aim the bat
- Click / Space: swing (one target per swing)
- E: open / close the shop
- P / Escape: pause / resume
- Sound button: optional synthesized effects
- Restart: immediately start a fresh run

Get within bat reach and aim at the target. Normal targets have a wider hit arc; golden targets need precision. Targets bounce and expire; expired normal targets cost 8 HP, golden ones 5 HP. Death ends the run. There is no victory screen.

## Progression
Each normal hit pays 10 points before upgrades. Every spawn independently has a 0.5% probability of being golden. Gold targets are smaller, 1.85× faster, evade you nearby, expire sooner, require a narrower hit angle, and pay exactly 20× the upgraded normal reward.

Score is cumulative; the separate point wallet buys reach, swing cooldown, movement speed, payout multipliers, or healing. Purchases happen only in the paused shop. Upgrades reset each run. Best score is stored locally when a run ends.

Difficulty depends on active playing time, not wall-clock time. Heat = 1 + 2(t/1200)^1.4 + max(0,t−1080)/30 + max(0,t−1200)/8. Higher heat increases spawn frequency and ball speed while shortening lifetimes. Pressure accelerates after 18 minutes, then escalates again at 20 minutes. This is designed to become overwhelming around 20 minutes, not to guarantee an exact death time for every player.

## Publish on GitHub Pages
1. Create a repository on GitHub, e.g. `midnight-bat-club`.
2. Extract this ZIP on your computer.
3. In the repository, choose **Add file → Upload files**. Upload `index.html`, `README.md`, and `.nojekyll` to the repository root, then commit.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main`, and select `/ (root)`. Save.
6. After the deployment finishes, open the published URL shown on that Pages screen.

If using Git instead, put the extracted files in your repository, commit, and push. No npm install or build command is required.

## Customize
All code, CSS, and drawing are inside `index.html`.
- `items`: upgrade descriptions, prices, limits
- `heat()`: difficulty curve
- `addBall()`: rarity, target size, and lifespan
- `swing()`: aim tolerances and rewards
- `draw()`: original pixel-art character, balls, court, and effects

The art is drawn with Canvas rectangles and contains no downloaded character sprites, music, or fonts. This is an unofficial fan-made interpretation, not an official or licensed Tung Tung Tung Sahur product. Before public release, check any rights associated with the character/name in your jurisdiction. No rights to third-party characters are granted by this project. No software license is supplied; add your preferred license if you want to grant reuse rights.

## Testing note
JavaScript syntax and pure gameplay math were checked programmatically during creation. Interactive visual and play-balance testing in a browser is still recommended, particularly for the late-game difficulty curve.
